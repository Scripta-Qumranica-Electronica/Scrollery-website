CREATE FUNCTION set_to_json_array(my_set VARCHAR(250))
  RETURNS VARCHAR(250)
  BEGIN
	 IF my_set IS NOT NULL AND my_set NOT LIKE '' THEN
				RETURN CONCAT('["', REPLACE(my_set,',','","'), '"]');
				ELSE
				RETURN '[]';
	END IF;
END;
