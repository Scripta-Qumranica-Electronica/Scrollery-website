CREATE PROCEDURE get_line_text(IN scroll_name VARCHAR(45), IN column_name VARCHAR(45), IN line_name VARCHAR(45))
    get_line_text:BEGIN
	DECLARE next_id_var		INTEGER;
	DECLARE break_type_var	INTEGER;
	DECLARE full_output		TEXT;
	DECLARE scroll_id		INTEGER;
	DECLARE column_count		INTEGER;
	DECLARE column_id	INTEGER;
	
	CALL get_scroll(scroll_name, scroll_id, full_output);
	
	IF full_output IS NOT NULL THEN
		SELECT full_output;
		LEAVE get_line_text;		
	END IF;
	
	call get_fragment(scroll_id, column_name,column_count, column_id, full_output);

	IF full_output IS NOT NULL THEN
		SELECT full_output;
		LEAVE get_line_text;		
	END IF;
	
	IF  column_count>1 THEN
		SELECT '{"ERROR_CODE":6, "ERROR_TEXT":"No unique fragment"}';
		LEAVE get_line_text;		
	END IF;
		
	SELECT 	CONCAT(',"LINES":[{"LINE":"', line_of_column_of_scroll.name, 
					'","LINE_ID":', line_of_column_of_scroll.line_id, 
					',"SIGNS":['),		
			position_in_stream.next_sign_id
		INTO full_output, next_id_var
		FROM line_of_column_of_scroll
		JOIN real_char_area ON real_char_area.line_of_scroll_id = line_of_column_of_scroll.line_id
		JOIN sign ON sign.real_char_areas_id=real_char_area.real_char_area_id
		JOIN position_in_stream ON position_in_stream.sign_id=sign.sign_id
		WHERE line_of_column_of_scroll.column_id = column_id
		AND line_of_column_of_scroll.name like line_name
		AND (sign.sign_id is null OR FIND_IN_SET('LINE_START', sign.break_type));
	
	SET full_output=CONCAT('{"SCROLL":"' , scroll_name, 
					'","SCROLL_ID":', scroll_id, 
					',"FRAGMENTS":[{',
					'"FRAGMENT":"', column_name,
					'","FRAGMENT_ID":', column_id, full_output);
	
	CALL get_sign_json(next_id_var, full_output);
		
	SELECT CONCAT(full_output, ']}]}]}');

END;
