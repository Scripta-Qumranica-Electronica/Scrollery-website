CREATE PROCEDURE getCatalogAndEdition(IN param_plate VARCHAR(45), IN param_fragment VARCHAR(45),
                                      IN param_side  TINYINT(1))
  select image_catalog.image_catalog_id, edition_catalog.edition_catalog_id 
from image_catalog 
left join image_to_edition_catalog on image_catalog.image_catalog_id = image_to_edition_catalog.catalog_id 
left join edition_catalog on edition_catalog.edition_catalog_id = image_to_edition_catalog.edition_id 
where image_catalog.catalog_number_1 = param_plate AND image_catalog.catalog_number_2 = param_fragment 
AND image_catalog.catalog_side = param_side;
