CREATE PROCEDURE get_fragment(IN  scroll_id   INT, INOUT column_name VARCHAR(45), OUT column_count INT,
                              OUT column_id   INT, INOUT full_output LONGTEXT)
  BEGIN
	
	SET column_name = CONCAT('^', column_name, '( [iv]+)?$');
	SELECT  
		column_of_scroll.column_of_scroll_id, 
		column_of_scroll.name,
		count(column_of_scroll.column_of_scroll_id)
	INTO column_id, column_name, column_count
	FROM column_of_scroll
	WHERE column_of_scroll.scroll_id=scroll_id
	AND column_of_scroll.name REGEXP column_name;
	
	IF column_count = 0 THEN
		SET full_output = '{"ERROR_CODE":5, "ERROR_TEXT":"Fragment not found"}';
	END IF;

END;
