CREATE PROCEDURE get_scroll(INOUT scroll_name VARCHAR(50), OUT scroll_id INT, INOUT full_output LONGTEXT)
  BEGIN
	SELECT `scroll`.scroll_id
	INTO scroll_id
	FROM `scroll`
	WHERE `scroll`.name like scroll_name;
	
	IF scroll_id IS NULL THEN
		SET full_output = '{"ERROR_CODE":4, "ERROR_TEXT":"Scroll not found"}';
	END IF;
END;
