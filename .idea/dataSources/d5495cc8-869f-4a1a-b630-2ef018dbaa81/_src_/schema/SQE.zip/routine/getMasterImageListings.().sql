CREATE PROCEDURE getMasterImageListings()
  select edition_catalog.composition, image_catalog.institution, image_catalog.catalog_number_1, image_catalog.catalog_number_2,  edition_catalog.edition_name, edition_catalog.edition_volume, edition_catalog.edition_location_1, edition_catalog.edition_location_2, SQE_image.sqe_image_id
from SQE_image 
left join image_catalog on image_catalog.image_catalog_id = SQE_image.image_catalog_id 
left join edition_catalog on edition_catalog.edition_catalog_id = SQE_image.edition_id
where SQE_image.is_master=1 AND image_catalog.catalog_side=0 order by edition_catalog.composition;
