CREATE PROCEDURE get_sign_json(IN next_id_var INT, INOUT full_output LONGTEXT)
  BEGIN
	SET @output_text ='';
	SET @is_last = 0;
	SET @next_id_var=next_id_var;
	
	PREPARE stm FROM 
		"SELECT \n\t\t\tIF(sign.sign_type_id=9, @output_text,\n\t\t\tCONCAT_WS('',@output_text,\n\t\t\t\t\t'{""SIGN_ID"":',sign.sign_id,', ',\n\t\t\t\t\t'""SIGN"":""',if(sign.sign like '',' ', sign.sign),'"", ', \n\t\t\t\t\t'""SIGN_TYPE"":""', sign_type.type,'"", ',\n\t\t\t\t\t'""SIGN_WIDTH"":', sign.width ,', ',\n\t\t\t\t\t'""MIGHT_BE_WIDER"":', if(might_be_wider, 'true', 'false') ,', ',\n\t\t\t\t\t'""READABILITY"":""', sign.readability,'"", ',\n\t\t\t\t\t'""IS_RECONSTRUCTED"":',if(is_reconstructed, 'true', 'false') ,', ',\n\t\t\t\t\t'""IS_RETRACED"":',if(is_retraced, 'true', 'false') ,', ',\n\t\t\t\t\t'""CORRECTION"":', set_to_json_array(sign.correction) ,', ',\n\t\t\t\t\t'""RELATIVE_POSITION"":[', (select \n\t\t\t\t\t\t\tCONCAT('""',GROUP_CONCAT(sign_relative_position.`type` ORDER BY LEVEL ASC SEPARATOR '"",""'),\n\t\t\t\t\t\t\t\t '""')\n\t\t\t\t\t\t\tFROM sign_relative_position\n\t\t\t\t\t\t\tWHERE sign_relative_position.sign_relative_position_id=sign.sign_id), \n\t\t\t\t\t']},')), \n\t\t\tposition_in_stream.next_sign_id,\n\t\t\tIFNULL(FIND_IN_SET('LINE_END',sign.break_type),0)\n\t\t\tINTO  @output_text, @next_id_var, @is_last\t\n\t\t\tFROM sign\n\t\t\tJOIN position_in_stream ON position_in_stream.sign_id=sign.sign_id\n\t\t\tJOIN sign_type ON sign_type.sign_type_id=sign.sign_type_id\n\t\t\tWHERE sign.sign_id=?";
			
	WHILE @is_last = 0   DO
		EXECUTE stm USING @next_id_var;
	END WHILE;
	DEALLOCATE PREPARE stm;
	SET full_output = concat(full_output, SUBSTRING(@output_text, 1, CHAR_LENGTH(@output_text)-1));
END;
