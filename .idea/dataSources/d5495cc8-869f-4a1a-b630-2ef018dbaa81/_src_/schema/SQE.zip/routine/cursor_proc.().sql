CREATE PROCEDURE cursor_proc()
  BEGIN
   DECLARE art_id INT UNSIGNED DEFAULT 0;
   -- this flag will be set to true when cursor reaches end of table
   DECLARE exit_loop BOOLEAN;         
   -- Declare the cursor
   DECLARE artefact_cursor CURSOR FOR
     SELECT artefact_id FROM artefact;
   -- set exit_loop flag to true if there are no more rows
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE;
   -- open the cursor
   OPEN artefact_cursor;
   -- start looping
   artefact_loop: LOOP
     -- read the name from next row into the variables 
     FETCH  artefact_cursor INTO art_id;
     -- check if the exit_loop flag has been set by mysql, 
     -- close the cursor and exit the loop if it has.
     IF exit_loop THEN
         CLOSE artefact_cursor;
         LEAVE artefact_loop;
     END IF;
     INSERT IGNORE INTO artefact_owner (artefact_id, scroll_version_id) VALUES(art_id, 1);
   END LOOP artefact_loop;
 END;
