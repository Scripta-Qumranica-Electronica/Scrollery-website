CREATE PROCEDURE get_arts()
  BEGIN
   DECLARE user_id INT UNSIGNED DEFAULT 0;
   IF user_id < 1 THEN
   
   SELECT distinct artefact.artefact_id as id, ST_AsText(ST_Envelope(artefact.region_in_master_image)) as rect, ST_AsText(artefact.region_in_master_image) as poly, ST_AsText(artefact.position_in_scroll) as pos, image_urls.url as url, image_urls.suffix as suffix, SQE_image.filename as filename, SQE_image.dpi as dpi from artefact_owner join artefact using(artefact_id) join scroll_version using(scroll_version_id) inner join SQE_image on SQE_image.sqe_image_id = artefact.master_image_id inner join image_urls on image_urls.id = SQE_image.url_code where artefact.scroll_id = 808 and artefact_owner.scroll_version_id=1;
   
   ELSE
   
   SELECT distinct artefact.artefact_id as id, ST_AsText(ST_Envelope(artefact.region_in_master_image)) as rect, ST_AsText(artefact.region_in_master_image) as poly, ST_AsText(artefact.position_in_scroll) as pos, image_urls.url as url, image_urls.suffix as suffix, SQE_image.filename as filename, SQE_image.dpi as dpi from artefact_owner join artefact using(artefact_id) join scroll_version using(scroll_version_id) inner join SQE_image on SQE_image.sqe_image_id = artefact.master_image_id inner join image_urls on image_urls.id = SQE_image.url_code where scroll_version.user_id = user_id and scroll_version.scroll_id = 808 and scroll_version.version = 0;
   
   
   END IF;
 END;
